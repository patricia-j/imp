//funçao1 ###############################
/*
//Funções nomeadas
function funcao1() {
    let let1 = "aula 2 js";
    return let1;
}

//chamada da função opção 1
funcao1();

//chamada da função opção 2
//troque a ordem de execução e veja o q acontece
console.log(funcao1()); 
*/
//funçao2 ##########################################

/*
//funçao com nomeada com parametro
function funcao1(parametro) {
    let let1 = "este é um parametro " + parametro;
    console.log("let 1 = " + let1);   
    return let1;
   
}
let qqcoisa = window.prompt("digite alguma coisa");

console.log(funcao1(qqcoisa));
*/

//funçao3 ##########################################
//funções anonimas 
/*
let funcao1 = function funcao1(semparar, dinheiro) {
    let let1 = "este função anonima " + parametro;
    return let1;
    console.log("let 1 = " + let1);
    }
    
let qqcoisa = console.log("digite alguma coisa")

console.log(funcao1(qqcoisa));
*/




















/*

//Exemplo2 funcao anonima nomeada. What the fluff...
(funcaoAnonima = function(param = "eu sou um param da funçao anonima ") {
    console.log('Eu sou uma IIFE, sou carregada imediatamente, no momento em que sou definida!!!' + param) ;
  }());

  let  testeFA = (funcaoAnonima = function(param = "eu sou um param da funçao anonima :)") {
    console.log('Eu sou uma IIFE, sou carregada imediatamente, no momento em que sou definida!!!' + param) ;
  }());
 */





 //funçao ##########################################
//immediately invoked function (IIFE) - carrega 

      (function() {


      }()); 

//Exemplo1*
/*
        (function() {
            console.log('Eu sou uma IIFE, sou carregada imediatamente, no momento em que sou definida!!!');
          }());
/*

    
*/
  
//criar um elemento  no dom ######################################################################
let meuH1 = document.createElement('h1');
meuH1.textContent = "Criado por função";
document.body.appendChild(meuH1);

//criar uma div
let minhaDiv = document.createElement('div');
minhaDiv.innerHTML = "JS Rules! :)";
minhaDiv.setAttribute('class', 'container');
minhaDiv.setAttribute('id','div2');
document.body.appendChild(minhaDiv);

//criar um h1 no lugar correto
let meuH1 = document.createElement("h1");
let node = document.createTextNode("Titulo 2 - JS");
meuH1.appendChild(node);

let element = document.getElementById("idH1");
element.appendChild(meuH1);


/*
//criar um elemento  no dom





*/



        
