(function () {
    // (function() {}());

    let minhaDiv = document.getElementById('div1');
    let ouveBtn = document.getElementById('btn1');
    let meuParag = document.getElementById('parag1')
    ouveBtn.addEventListener('click', addClass);
    function addClass() { minhaDiv.setAttribute('class', 'container') };
    meuParag.addEventListener('click', function () { minhaDiv.style.background = "lightblue" });



    //evento esconde exibe imagem #######

    let esconderImagem = document.getElementById('esconderImagem');
    //let imagem = document.getElementById('meme');

    let exibirImagem = document.getElementById('exibirImagem');


    esconderImagem.addEventListener("click", f_escondeImg);

    function f_escondeImg() {
        let imagem = document.getElementById('meme');
        imagem.style.display = 'none';
    };

    exibirImagem.addEventListener('click', f_exibeImg);

    function f_exibeImg() {
        let imagem = document.getElementById('meme');
        imagem.style.display = 'inline';
    };


    //opção de correção do exercicio da ação no mesmo botão, isso tb serve para a outra situação d

    let escondeExibe = document.getElementById('escondeExibe');
    escondeExibe.addEventListener('click', btnEscondeExibe);

    function btnEscondeExibe() {
        let minhaclasse = document.querySelector('#meme').getAttribute('class');

        if (minhaclasse == "format") {

            document.querySelector('#meme').setAttribute('class', 'esconde');

        }
        if (minhaclasse == 'esconde') {

            document.querySelector('#meme').setAttribute('class', 'format');

        }
    };








    /* 
    
        //evento teclado #####
    //referencia interessante evento keyboard
    https://javascript.info/keyboard-events
    
    
        //refencia - http://keycode.info/  
    
        let textbox = document.getElementById("meuInput");
    
        textbox.addEventListener("keyup", escrever);
    
        function escrever() {
            let inputValor = this.value;
            document.getElementById("respostaEvento").innerHTML = inputValor;
        };
    
    
     */


    //evento teclado #####






    //modal ##############        
    let modal = document.getElementById('customModal');
    let btn = document.getElementById("btnModal");
    let span = document.getElementsByClassName("close")[0];

    btn.onclick = function () {
        modal.style.display = "block";
    }
    span.onclick = function () {
        modal.style.display = "none";
    }
    window.onclick = function (event) {
        if (event.target == modal) {
            modal.style.display = "none";
        }
    }
    //modal ##############   



}());

/*
    EXERCICIO 1
    CRIAR O JS DO BOTÃO CLIQUE AQUI - O USUARIO CLICA 1 VEZ
    A IMG SOME, CLICA DE NOVO E A IMG APARECE;

    EXERCICIO 2 
    CRIAR UM COMPONENTE QUE MUDE O BACKGROUND DE COR QDO CLICADO;

    */