(function () { 
    //javascript object literal tipo
  /*
 //declarando um objeto 
    let minhaVariavel = "qualquer coisa";
    console.log(minhaVariavel);

*/

//######################################################
/*

 //Construindo um objeto   
    let minhaVariavelOBJ = {
        prop: "qualquer coisa",
        prop1: "eu sou a propriedade 1",
        prop2: "eu sou a propriedade 2",
        prop3: "acho que já deu pra entender"       

    };

    console.log(minhaVariavelOBJ);
    console.log(minhaVariavelOBJ.prop3);
*/
//############################################################
/*
//Criando um objeto com métodos
    let minhaVariavelOBJ = {
        prop: "qualquer coisa",
        prop1: "eu sou a propriedade 1",
        prop2: "eu sou a propriedade 2",
        prop3: "acho que já deu pra entender",
        metodo1(){
            console.log(this.prop2 + 'voce chamou o metodo1')
        },
        metodo2(){
            console.log(' voce chamou o metodo2 ' + this.prop3)
        }, 

    };
    console.log(minhaVariavelOBJ);
    console.log(minhaVariavelOBJ.prop1);
    console.log(minhaVariavelOBJ.metodo1());

   
    console.log(minhaVariavelOBJ.prop + " antes da atualização");
    minhaVariavelOBJ.prop = "mudei a propriedade";
    console.log(minhaVariavelOBJ.prop + "  depois da atualização");

    let testepassVar = minhaVariavelOBJ.prop
    console.log(testepassVar + " ... e passei a propriedade para uma variavel");

*/
//############################################

/*
    //Criando Classes para criar novos objetos
   class MinhaClasse  {
        constructor(){
            
        } 
        }

        let objMinhaClasse = new MinhaClasse();

*/


//##################################
/*
//Criando classe com parametros para serem acessados
    class MinhaClasse  {
        constructor( parametro1fora, parametro2, parametro3){
            this.parametro1dentro = parametro1fora,
            this.parametro2 = parametro2,
            this.parametro3 = parametro3
        } 
        };
//criar objetos do mesmo tipo 
        let objMinhaClasse = new MinhaClasse('flavia', 'talita', 'karina');
        console.log(objMinhaClasse);
*/

//###############################3


//Adicionando os métodos da classe
    class MinhaClasse  {
        constructor( parametro1, parametro2, parametro3){
            this.parametro1 = parametro1,
            this.parametro2 = parametro2,
            this.parametro3 = parametro3
        } 

        //adicionar fora do construtor, nao utilizar virgula
        metodo1(){
            console.log(this.parametro1 + 'voce chamou o metodo1')
        }
        metodo2(){
            console.log(' voce chamou o metodo2 ' + this.parametro2)
        }

        };
//criar objetos do mesmo tipo 
        let objMinhaClasse = new MinhaClasse('meuparametro1', 'meuparametro2', 'meuparametro3');

        console.log(objMinhaClasse.parametro1 + " ...chamando o obj");

        console.log(objMinhaClasse.metodo2() + " chamando um método");



//########################## Herança - mesma classe com novos métodos, ou propriedades

class HerdaMinhaClasse extends MinhaClasse{
    metodoHerdaMinhaClasse(){
        console.log("sou o metodo herda minha classe")
    }

}

let meuHerdeiro = new HerdaMinhaClasse();

console.log(meuHerdeiro.metodoHerdaMinhaClasse());


// executar os codigos da apostila 
//criar uma calculadora que receba 2 parametros e realize as 4 operações matematicas


*/
}());
