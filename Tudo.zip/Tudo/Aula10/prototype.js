function MeuPrototype( parametro1, parametro2){
    this.parametro1 = parametro1;
    this.parametro2 = parametro2;
  }


MeuPrototype.prototype.funcao1 = function(){ 
    this.parametro1 = "... eu sou o parametro 1";
    console.log(this.parametro1 + " mensagem");
 }

 
MeuPrototype.prototype.funcao2 = function(){
    this.parametro2 =  " ... eu sou o parametro 2";
    console.log(this.parametro2 + " mensagem");
 }


let objPrototype1 =  new MeuPrototype('parametro1', 'parametro2');
let objPrototype2 = new MeuPrototype('outroparametro1', 'outroparametro2');

console.log(objPrototype1);
console.log(objPrototype2.funcao1());