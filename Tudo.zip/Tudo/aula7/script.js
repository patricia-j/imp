
alert("OI 2");

var numero = "meu texto string";
var numero = "10";


  



    // hoisting1
    var varVariable = 'este é uma variavel do tipo var';
    var varVariable = 'este é uma variavel do tipo var de novo';
    let letVariable = 'este é uma variavel do tipo let';
    //let letVariable = 'este é uma variavel do tipo let';
    
    console.log(window.varVariable); //,.sdhfkljahldksfhka
    console.log(window.letVariable);

    document.write(varVariable);
    document.write(letVariable);

    console.log(varVariable);
    console.log(letVariable);


outras variaveis:

let num1 = 10; //window.prompt("");
let num2 = "10";
console.log(typeof (num1)); //verifica o tipo 
console.log(typeof (num2)); // verifica o tipo

if (num1 === num2) { //pergunta se é o mesmo tipo e o mesmo valor
    console.log(num1 === num2); //mesmo tipo e mesmo valor verdadeiro
} else {
    console.log(num1 === num2); //mesmo tipo e mesmo valor falso
}
/*
diferente: !=
maior: >
menor: < 
maior igual: >=
menor igual: <=



console.log(num1 + num2);
console.log(num1 - num2);
console.log(num1 * num2);
console.log(num1 / num2);
console.log(num1 % num2); */


    let  item = "qualquer coisa";
    console.log(item.indexOf("c"));
    

    let num = 50;
    
    if (num < 10) {
        console.log("valor é: " + num);

    } else if (num < 10) {
        console.log("valor é: " + num);
    } 
    else if (num < 20) {
        console.log("valor é: " + num);
    }else {
        console.log("valor é: " + num);
    }


    let copaDoMundo = [
        'Brasil', // [0]
        'Argentina', // [1]
        'Alemanha', // [2]
        'Portugal' // [3]
    ];

   //inicio estrutura looping
for(var i=0; i<copaDoMundo.length; i++) {
    console.log(copaDoMundo[i]);
    
    
    let copaDoMundo = [
        'Brasil', // [0]
        '4', // [1]
        'true', // [2]
        'Portugal' // [3]
    ];
   
   console.log(copaDoMundo.length);

    
for(let i = 0; i < copaDoMundo.length; i++) {
   
    console.log("valor de i: " + i );
    console.log(copaDoMundo[i]);
   
}
 console.log(typeof(copaDoMundo));

 //fim estrutura looping
}
    // verificar o tamanho da lista
    console.log(copaDoMundo.length);

    // encontrar um valor pelo indice
    let indiceLista = copaDoMundo[0];
    console.log(indiceLista);

    // Adiciona um elemento na lista copaDoMundo
    copaDoMundo.push('Bélgica');
    console.log(copaDoMundo);

    // Remove Ãºltimo item da lista
    copaDoMundo.pop();
    console.log(copaDoMundo);

    // Exclui o primeiro da lista
    copaDoMundo.shift();
    console.log(copaDoMundo);

    // Deleta em uma posicao ou intervalo especi­fico (posicao, quantidade)
    copaDoMundo.splice(1, 1);
    console.log(copaDoMundo);

    // Insere um elemento no comeÃ§o da lista
    copaDoMundo.unshift('Colombia');
    console.log(copaDoMundo);

    // Encontra o indice pelo valor do item
    let indice = copaDoMundo.indexOf("Alemanha");
    console.log(indice);

    //percorrendo uma lista e encontrando um valor
    copaDoMundo.forEach(function (item, index) {
        console.log(item, index);
    });

    //cria copia da lista

    var copaCopia = copaDoMundo.slice();


    let pessoa = {
        nome: 'Brad Pitt',
        idade: 50,
        nacionalidade: 'gringo',
        naturalidade: 'Oklahoma'
    };
    console.log(pessoa);

    // Deletar propriedade de um objeto
    delete pessoa.idade;
    delete pessoa['idade'];

    pessoa.corFavorita = 'Azul';
   
    console.log(pessoa);
    alert(pessoa.nome);
    document.write(pessoa.nacionalidade);
    delete pessoa.idade;
    console.log(pessoa);

    let amigos = [
        { nome: 'João', idade: 21 },
        { nome: 'Maria', idade: 19 }
    ];
   
    

    //console.log da idade do jo...
    console.log(amigos[0].idade);

    let idadeDaPessoa = 21;
    let idadePermitida = 18;
    if (idadeDaPessoa < idadePermitida) {
        // se for verdadeiro
        //console.log('Acesso negado');
    } else {
        // se for falso
        console.log('acesso permitido');
    }

    let notaFinal = 6;
    let notaQueReprova = 5;
    let notaQueAprova = 7;
/* 
    //manipular DOM 1 id
   html:
    <p id="customP" class="customClass">OI eu sou um paragrafo</p>

        <p>demo de como <b>getElementById</b> metodo  é usado</p>
        
      <p id="demo"></p>

    

    //  js
    let  let1 = document.getElementById("customP");
    let  let1 = document.querySelector("#customP);


    document.getElementById("demo").innerHTML = 
    "o texto do p é: " + myElement.innerHTML;

    let let2 = document.querySelectorAll("p.intro"); */

   /*  manipular DOM 2 Classe
        let let2 = document.querySelectorAll("p.customClass");
        
        document.getElementById("demo").innerHTML =
            'Primeiro p com classe customClass: ' + let2[1].innerHTML;
 
 */



