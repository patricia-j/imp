$(function () {

    $("#salvar").click(function () {

        if ($("#nome").val() !== "" && $("#sobrenome").val() !== "") {
            localStorage.setItem("nome", $("#nome").val());
            localStorage.setItem("sobrenome", $("#sobrenome").val());

            alert('LocalStorage atualizado com sucesso contendo ' + localStorage.length);

            $("#nome").val("");
            $("#sobrenome").val("");

        }

    });

    $("#salvar2").click(function () {

        localStorage.removeItem("nome");
        localStorage.removeItem("sobrenome");

        alert('local storage excluido');
        //localStorage.clear(); remove tudo

    });

});