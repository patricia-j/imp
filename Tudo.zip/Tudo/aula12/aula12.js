$(function () {



    let $usuarios = $('#listausers');
    console.log($usuarios);

    $.ajax({
        url: "https://reqres.in/api/users?page=3",
        type: "GET",
        success: function (dados) {
            console.log('success', dados);

            //coloca os elementos na pagina:
            $.each(dados.data, function (i, usuario) {
                $usuarios.append('<li>Nome: ' + usuario.first_name + ' </li>')
                //  first_name: "George", last_name: "Bluth", avatar: "https://s3.amazonaws.com/uifaces/faces/twitter/calebogden/128.jpg"
            
            });
        },
        error: function () {
            alert('deu um erro em algum lugar');
        }
    });







    //################# post
    let $nome = $('#nome');
    let $sobrenome = $('#sobrenome');

    $('#postar').click(function () {
        $.ajax({
            url: "https://reqres.in/api/users",
            type: "POST",

            data: {
                first_name: $nome.value,
                last_name: $sobrenome.value
            },
            success: function (response) {
               console.log(response);

            }
        });
    });




});