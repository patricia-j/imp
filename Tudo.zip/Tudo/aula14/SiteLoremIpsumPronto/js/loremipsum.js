//bootstrap lista de classes
//https://hackerthemes.com/bootstrap-cheatsheet/
//form validation - https://stackoverflow.com/questions/15060292/a-simple-jquery-form-validation-script


//
(function () {
      //animação do botão outra opção em Contact
//  #### botão outra opção
      let $opcaobutton = $("#opcaobutton");
    
      $("#escolhaDropdown li a").on("click", function () {
        let opcao = $(this).text();
        $opcaobutton.text(opcao);
      });
      //  #### botão outra opção fim

      
   //##### modal 
      let $meuModal = $("#meuModal");
    
      $("#meuForm").on("submit", function () {
        $meuModal.modal('show');
        return false;
      }); 

       //##### modal fim
    
    $("#theCarousel").carousel();
  
  })();