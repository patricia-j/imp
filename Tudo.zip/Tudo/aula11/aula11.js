  



  let xhttp = new XMLHttpRequest();
  
  xhttp.onreadystatechange = function() {
      if (this.readyState == 4 && this.status == 200) {
        // console.log(xhttp.responseText + "resposta http");
        console.log(xhttp.status + " status http")
        let response = JSON.parse(xhttp.responseText);
        let people = response.people;

        //
        let inserehtml = '';
        for(let i = 0;i < people.length;i++){
          inserehtml += '<li>'+people[i].name+'</li>';
        }
        document.getElementById('people').innerHTML = inserehtml;
      }
  };
  xhttp.open("GET", "people.json", true);
  xhttp.send();





