(function() {

let btnBuscarCep = document.querySelector('#btnBuscarCep');
let cepDigitado = document.querySelector('#cepDigitado');
let bairro = document.querySelector('#bairro');
let localidade = document.querySelector('#localidade');
let logradouro = document.querySelector('#logradouro');

//passando parametros para o event listener
btnBuscarCep.addEventListener('click', function() {    
    buscaCep(cepDigitado.value);
});

function buscaCep(cepDigitadoPeloUsuario) {

    fetch('https://viacep.com.br/ws/'+ cepDigitadoPeloUsuario +'/json/', {
              method: 'GET'
    }).then(function(response) {
        response.json().then(function(dados){
            console.log(response)            
            console.log(dados)

            bairro.innerHTML = dados.bairro;
            localidade.innerHTML = dados.localidade;
            logradouro.innerHTML = dados.logradouro
        })
    }).catch(function(error) {
        console.log(error);
    })

    //referencia
    //https://developer.mozilla.org/pt-BR/docs/Web/API/Fetch_API/Using_Fetch
    //https://viacep.com.br/

}








})();