$(function() {

    $('#injetaJquery').html('Escreva menos, faça mais');

   
    let body = $('body');
    let mudarCor = $('#btn1');   
    let imagem = $('#meme1');
    let esconderImagem = $('#btn2');
    let exibirImagem = $('#btn3');
    let escondeExibe = $('#btn4');
  
 
    
    mudarCor.click(function() {body.addClass('background1');});

    esconderImagem.click(function() {
        imagem.fadeOut();
    });

    exibirImagem.click(function() {
        imagem.fadeIn();
    });

    escondeExibe.click(function() {
        imagem.slideToggle();
    });
   

let divs = $( "div" ).length;
alert( "tenho " + divs + "divs");

 $('div').each(function(){
  alert($(this).html());
$(this).addClass('class5');
 

 });

 
});